#!/usr/bin/env python
# -*- coding: utf-8 -*-
from CVariable import *
from Angle import *
from Id import *
from CError import *

cError = CError()

fiveCC = CFiveCC("abd?*",cError)
print fiveCC.toString()

cTime = CTime("12:31:20:19",cError)
print cTime.toString()


cTime.set("水:20:19",cError)
print cTime.toString()

if (cError.isError()):
	cError.output()
	exit(-1)