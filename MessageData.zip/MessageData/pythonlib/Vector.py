#!/usr/bin/env python
# -*- coding: utf-8 -*-
from struct import *

#
# Vector2
#
class Vector2:
	x = 0.0
	y = 0.0
	def __init__ (self):
		self.x = 0.0
		self.y = 0.0
#
# Vector3
#
class Vector3:
	x = 0.0
	y = 0.0
	z = 0.0
	def __init__ (self):
		self.x = 0.0
		self.y = 0.0
		self.z = 0.0
	
#
# Vector4
#
class Vector4:
	x = 0.0
	y = 0.0
	z = 0.0
	w = 0.0
	def __init__ (self):
		self.x = 0.0
		self.y = 0.0
		self.z = 0.0
		self.w = 0.0
#
# Quaternion
#
class Quaternion:
	x = 0.0
	y = 0.0
	z = 0.0
	w = 0.0
	def __init__ (self):
		self.x = 0.0
		self.y = 0.0
		self.z = 0.0
		self.w = 0.0

